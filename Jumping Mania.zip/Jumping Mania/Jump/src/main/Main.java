package main;

import entity.Entity;

public class Main {

    public static void main(String args[]) {
        new TitlePage();
    }
}

